class Difficult:
	pass