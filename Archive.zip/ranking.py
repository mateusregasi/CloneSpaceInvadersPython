class Ranking:
	pass