from scene import Scene

class Game(Scene):
	
	def __init__(self, args):
		super.__init__(args)