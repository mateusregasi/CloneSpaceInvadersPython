# CloneSpaceInvadersPython
O atual repositório consiste em um trabalho realizado por mim durante a disciplina de Laboratório de Desenvolvimento de Jogos no segundo período de Ciência da Computação pela UFF, em 2023.
